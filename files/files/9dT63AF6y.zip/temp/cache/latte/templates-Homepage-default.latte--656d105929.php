<?php
// source: C:\OpenServer\domains\nette\app\presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template656d105929 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<h1>Hello World</h1>

<h3>This website built in Nette Framework</h3><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}

}
