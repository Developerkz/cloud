<?php

$container = require '../app/bootstrap.php';

$container->getByType(Nette\Application\Application::class)->run();
